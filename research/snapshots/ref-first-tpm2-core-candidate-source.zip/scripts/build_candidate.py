#!/usr/bin/env python3
"""Build an UNTESTED TPM2 discovery candidate without overwriting board state.

No programmer operations. Reference builds require --reference; board builds
require two identical full reads. All additions occupy validated erased FV tails.
"""
import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STOCK = ROOT / 'Official_latest_bios_update/DOS Flash/L01_0278.BIN'
STOCK_SHA = 'c13e4495042f0bda3deadf4d110bf241cdeb6679153cde001b24e7e337b4e2c1'
DONOR_SHA = '29e07b5287eeaebdc338ed57523d649e9d4f7f79a501fa708d9f18b0f4329463'
PEI_POLICY = 'a4910111-b50a-401d-8b35-5124b0ba4104'
DXE_POLICY = 'a4910222-e072-40d2-a6eb-bab75bde87e7'
TPM_PPI = '86f5680a-155c-4bc8-ac77-573848e2ad3d'
MEMORY = '3cdc90c6-13fb-4a75-9e79-59e9dd78b9fa'
TCG2 = '607f766c-7455-42be-930b-e4d76db2720f'
ACPI = 'ffe06bdd-6107-46a6-7bb2-5a9c7ec5275c'
FVS = [(0x5e0000,0x8b0000),(0xeb0000,0xa0000),(0xf50000,0xa0000)]
PATCHES = {
    'TrEEPei': (0xa76b4e22,0xa4910111,[0x7b8,0xac2]),
    'TrEEDxe': (0xbb6cbeff,0xa4910222,[0x2cf,0x9a0,0x1431,0x1e0e]),
}
CORE_SHA = {
    'TrEEPei':'d995c97b720367873ed1d4b7dd15cb4d413984474a7858a60246c115c9583471',
    'TrEEDxe':'6ceb1fad2345e84e54e506edafb0f3b106061de9791ae66704472cd3a6e609b3',
}
DEP_SHA = {
    'TrEEPei':'7f9372bfeb36a6bc09e74c368a022543b42b3fd6ca4351118795c4833e757908',
    'TrEEDxe':'409a03c2a3b3017702b3bd5095dacbead20985af5676b34705a6ea0a8945b192',
}

def require(condition,message):
    if not condition: raise ValueError(message)

def digest(data): return hashlib.sha256(data).hexdigest()
def align(n,a): return (n+a-1)&~(a-1)
def guid(s): return uuid.UUID(s).bytes_le
def push(s): return b'\x02'+guid(s)

def depex_and(*guids):
    out=push(guids[0])
    for g in guids[1:]: out+=push(g)+b'\x03'
    return out+b'\x08'

def add_dependency(expression,g):
    require(expression[-1:]==b'\x08','DEPEX missing END')
    return expression[:-1]+push(g)+b'\x03\x08'

def section(kind,data):
    size=len(data)+4
    require(size<0xffffff,'Large sections unsupported')
    return size.to_bytes(3,'little')+bytes([kind])+data

def ffs(name,kind,sections):
    body=bytearray()
    for s in sections:
        body.extend(b'\0'*(align(len(body),4)-len(body)))
        body.extend(s)
    header=bytearray(guid(name)+b'\0\0'+bytes([kind,0x40])+(len(body)+24).to_bytes(3,'little')+b'\xf8')
    header[17]=(-sum(body))&255
    header[16]=(-(sum(header)-header[17]-header[23]))&255
    blob=bytes(header+body)
    validate_ffs(blob)
    return blob

def validate_ffs(blob):
    require(len(blob)>=24,'Truncated FFS')
    require(int.from_bytes(blob[20:23],'little')==len(blob),'FFS size mismatch')
    require((sum(blob[:24])-blob[17]-blob[23])&255==0,'FFS header checksum')
    if blob[19]&0x40: require((sum(blob[24:])+blob[17])&255==0,'FFS data checksum')

def inventory(data,base,length):
    require(len(data)==0x1000000,'Expected full 16 MiB image')
    require(data[base+40:base+44]==b'_FVH','FV signature mismatch')
    require(struct.unpack_from('<Q',data,base+32)[0]==length,'FV length mismatch')
    hlen=struct.unpack_from('<H',data,base+48)[0]
    require(hlen>=56 and hlen%2==0 and hlen<length,'FV header size')
    require(sum(struct.unpack('<'+'H'*(hlen//2),data[base:base+hlen]))&65535==0,'FV checksum')
    require(struct.unpack_from('<I',data,base+44)[0]&0x800,'Expected erased polarity FF')
    ext=struct.unpack_from('<H',data,base+52)[0]
    off=align(base+hlen,8)
    if ext:
        require(ext+20<length,'FV extension offset')
        extsize=struct.unpack_from('<I',data,base+ext+16)[0]
        require(extsize>=20 and ext+extsize<length,'FV extension size')
        off=align(base+ext+extsize,8)
    rows=[]
    while off+24<=base+length:
        if data[off:off+24]==b'\xff'*24:
            require(data[off:base+length]==b'\xff'*(base+length-off),'Non-erased FV tail')
            return rows,off
        size=int.from_bytes(data[off+20:off+23],'little')
        require(not(data[off+19]&1),'Large-file FFS unsupported')
        require(24<=size<0xffffff and off+size<=base+length,'Invalid existing FFS bounds')
        rows.append((str(uuid.UUID(bytes_le=bytes(data[off:off+16]))),data[off+18],off,size))
        off=align(off+size,8)
    raise ValueError('No usable erased FV tail')

def patch_core(name,data):
    require(digest(data)==CORE_SHA[name],name+' source PE hash mismatch')
    old,new,offsets=PATCHES[name]
    a=old.to_bytes(4,'little'); b=new.to_bytes(4,'little')
    require(data.count(a)==len(offsets),name+' unexpected policy literal occurrence count')
    out=bytearray(data)
    for offset in offsets:
        require(data[offset:offset+4]==a,name+' expected policy patch bytes absent')
        out[offset:offset+4]=b
    return bytes(out)

def compile_driver(source,out,pei=False):
    cc=shutil.which('clang')
    ld=shutil.which(('i686' if pei else 'x86_64')+'-w64-mingw32-ld')
    require(cc and ld,'Need clang and existing mingw-w64 GNU PE linkers')
    target='i686' if pei else 'x86_64'
    obj=out.with_suffix('.obj')
    args=[cc,'--target='+target+'-pc-windows-msvc','-Oz','-ffreestanding','-fno-builtin',
          '-fno-stack-protector','-fno-asynchronous-unwind-tables','-fno-unwind-tables',
          '-mno-sse','-mno-mmx','-Wall','-Wextra','-Werror','-I',str(ROOT/'src'),'-I',str(ROOT/'build')]
    if pei: args+=['-DBUILD_PEI']
    else: args+=['-mno-red-zone']
    subprocess.run(args+['-c',str(source),'-o',str(obj)],check=True)
    anchor=out.with_suffix('.anchor.obj')
    subprocess.run(args+['-c',str(ROOT/'src/relocation_anchor.c'),'-o',str(anchor)],check=True)
    subprocess.run([ld,'-m'+('i386pe' if pei else 'i386pep'),'--subsystem','11','--entry',
        '_efi_main' if pei else 'efi_main','--image-base','0x10000000' if pei else '0x180000000',
        '--section-alignment','0x20','--file-alignment','0x20','--no-insert-timestamp',
        '--enable-reloc-section','-o',str(out),str(obj),str(anchor)],check=True)
    data=out.read_bytes(); pe=struct.unpack_from('<I',data,60)[0]; opt=pe+24
    require(data[pe:pe+4]==b'PE\0\0','Bad linked PE')
    require(struct.unpack_from('<H',data,pe+4)[0]==(0x14c if pei else 0x8664),'PE machine')
    require(struct.unpack_from('<I',data,opt+16)[0]!=0,'PE entry absent')
    require(struct.unpack_from('<H',data,opt+68)[0]==11,'PE subsystem')
    reloc=opt+(96 if pei else 112)+5*8
    require(all(struct.unpack_from('<II',data,reloc)),'PE relocation directory absent')
    imports_rva,imports_size=struct.unpack_from('<II',data,opt+(96 if pei else 112)+8)
    if imports_rva or imports_size:
        # GNU PE ld emits an all-zero null import descriptor even without imports.
        count=struct.unpack_from('<H',data,pe+6)[0]
        sect=opt+struct.unpack_from('<H',data,pe+20)[0]
        found=False
        for i in range(count):
            virtual_size,rva,raw_size,raw_offset=struct.unpack_from('<IIII',data,sect+i*40+8)
            if rva<=imports_rva and imports_rva+imports_size<=rva+raw_size:
                start=raw_offset+imports_rva-rva
                require(data[start:start+imports_size]==b'\0'*imports_size,'Unexpected nonempty PE imports')
                found=True
        require(found,'Unmapped PE import directory')
    return data

def pack_driver(name,fileguid,pe,dependency,pei=False):
    return ffs(fileguid,6 if pei else 7,[section(0x1b if pei else 0x13,dependency),
        section(0x10,pe),section(0x15,(name+'\0').encode('utf-16-le'))])

def build_modules():
    build=ROOT/'build';build.mkdir(exist_ok=True)
    subprocess.run(['python3',str(ROOT/'scripts/generate_tpm2_acpi.py')],check=True,cwd=ROOT)
    policy_pei=compile_driver(ROOT/'src/tpm2_policy.c',build/'policy_pei.efi',True)
    policy_dxe=compile_driver(ROOT/'src/tpm2_policy.c',build/'policy_dxe.efi')
    init_pei=compile_driver(ROOT/'src/tpm2_init_pei.c',build/'init_pei.efi',True)
    acpi_dxe=compile_driver(ROOT/'src/tpm2_acpi.c',build/'acpi_dxe.efi')
    items={
        'PolicyPei':pack_driver('L01 diagnostic private TPM2 policy PEI','b6c97b11-4631-4ed0-9d24-3ec90187ef11',policy_pei,depex_and(MEMORY),True),
        'InitPei':pack_driver('L01 diagnostic TPM2 startup PEI','b6c97b12-4631-4ed0-9d24-3ec90187ef11',init_pei,depex_and(TPM_PPI,PEI_POLICY,MEMORY),True),
        'PolicyDxe':pack_driver('L01 diagnostic private TPM2 policy DXE','b6c97b13-4631-4ed0-9d24-3ec90187ef11',policy_dxe,b'\x06\x08'),
        'AcpiDxe':pack_driver('L01 diagnostic TPM2 ACPI DXE','b6c97b14-4631-4ed0-9d24-3ec90187ef11',acpi_dxe,depex_and(TCG2,ACPI)),
    }
    for name,fileguid,private,pei in [('TrEEPei','20341ce2-d448-4b5e-9411-fe9826402dcf',PEI_POLICY,True),
                                    ('TrEEDxe','12345756-fca3-49bd-8dae-c7bae8389aff',DXE_POLICY,False)]:
        pe=(ROOT/'inputs/core'/f'{name}.pe32').read_bytes()
        dep=(ROOT/'inputs/core'/f'{name}.depex').read_bytes()
        require(digest(dep)==DEP_SHA[name],name+' source DEPEX hash mismatch')
        items[name]=pack_driver(name+' isolated policy',fileguid,patch_core(name,pe),add_dependency(dep,private),pei)
    for name,blob in items.items(): (build/(name+'.ffs')).write_bytes(blob)
    return items

def apply_modules(base,stock,items):
    out=bytearray(base);writes=[]
    for i,(fv,length) in enumerate(FVS):
        rows,start=inventory(base,fv,length);stockrows,_=inventory(stock,fv,length)
        require([(g,t,n) for g,t,o,n in rows]==[(g,t,n) for g,t,o,n in stockrows],
                'Base FV existing file layout differs from stock L01 02.78')
        names=['PolicyDxe','TrEEDxe','AcpiDxe'] if i==0 else ['PolicyPei','TrEEPei','InitPei']
        present={g for g,t,o,n in rows}
        off=start
        for name in names:
            blob=items[name];g=str(uuid.UUID(bytes_le=blob[:16]))
            require(g not in present,'Module GUID collision: '+g)
            require(off+align(len(blob),8)<=fv+length,'Insufficient free FV tail')
            require(base[off:off+len(blob)]==b'\xff'*len(blob),'Insertion is not erased')
            out[off:off+len(blob)]=blob
            writes.append({'name':name,'offset':off,'size':len(blob),'guid':g,'sha256':digest(blob)})
            off+=align(len(blob),8);present.add(g)
        post,_=inventory(out,fv,length)
        require(len(post)==len(rows)+len(names),'Inserted file count mismatch')
        for g,t,o,n in rows: require(out[o:o+n]==base[o:o+n],'Existing file changed')
    # Every modified byte must fall inside an insertion, not merely inside a FV.
    covered=bytearray(len(base))
    for w in writes: covered[w['offset']:w['offset']+w['size']]=b'\x01'*w['size']
    require(all(a==b or covered[i] for i,(a,b) in enumerate(zip(base,out))),'Change outside insertions')
    require(out[0:0x5e0000]==base[0:0x5e0000],'Platform regions changed')
    require(out[0xff0000:]==base[0xff0000:],'Boot block changed')
    return bytes(out),writes

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,default=STOCK)
    p.add_argument('--second-read',type=Path)
    p.add_argument('--reference',action='store_true')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();stock=STOCK.read_bytes();base=a.base.read_bytes()
    require(digest(stock)==STOCK_SHA,'Stock reference hash mismatch')
    require(digest((ROOT/'inputs/donor/X10SLM0.414').read_bytes())==DONOR_SHA,'Donor image hash mismatch')
    require(not a.output.exists(),'Output already exists; choose a new path')
    require(not a.output.with_suffix(a.output.suffix+'.json').exists(),'Manifest already exists')
    if a.reference:
        require(base==stock,'Reference mode requires stock image')
        require('REFERENCE_ONLY' in a.output.name,'Reference output name must contain REFERENCE_ONLY')
        require(not a.second_read,'Reference mode does not attest board reads')
    else:
        require(a.second_read is not None,'Board build requires --second-read')
        require(a.second_read.resolve()!=a.base.resolve(),'Need two distinct read files')
        require(a.second_read.read_bytes()==base,'Board reads do not match')
        require(base!=stock,'Vendor image is not a board backup')
    modules=build_modules();out,writes=apply_modules(base,stock,modules)
    manifest={'status':'UNTESTED_DISCOVERY_EXPERIMENT','reference_only':a.reference,
        'base_path':str(a.base.resolve()),'base_sha256':digest(base),
        'second_read_path':str(a.second_read.resolve()) if a.second_read else None,
        'stock_sha256':digest(stock),'donor_sha256':DONOR_SHA,'output_sha256':digest(out),
        'size':len(out),'changed_bytes':sum(x!=y for x,y in zip(base,out)),'insertions':writes,
        'private_policy_patches':PATCHES,
        'compiler':subprocess.check_output(['clang','--version'],text=True).splitlines()[0],
        'source_sha256':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in
            sorted([*ROOT.glob('src/*'),*ROOT.glob('scripts/*.py')]) if p.is_file()},
        'linkers':{n:subprocess.check_output([n+'-w64-mingw32-ld','--version'],text=True).splitlines()[0]
            for n in ['i686','x86_64']},
        'limitations':['No hardware boot test','No production measured-boot/attestation claim',
            'No physical presence/TPM clear/provisioning UI','No S3 acceptance',
            'Reference images must not replace board-specific SPI data']}
    a.output.write_bytes(out)
    a.output.with_suffix(a.output.suffix+'.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'output':str(a.output),'sha256':digest(out),'changed_bytes':manifest['changed_bytes'],'status':manifest['status']},indent=2))

if __name__=='__main__': main()
