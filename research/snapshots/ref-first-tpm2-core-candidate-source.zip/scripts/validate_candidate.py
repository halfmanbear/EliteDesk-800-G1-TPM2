#!/usr/bin/env python3
"""Compare independent UEFIExtract diagnostics and preserve validation evidence."""
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'analysis/validation'
OUT.mkdir(parents=True,exist_ok=True)
subprocess.run(['python3',str(ROOT/'scripts/test_tpm2_acpi.py')],check=True,cwd=ROOT)
subprocess.run(['clang','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',
                str(ROOT/'tests/test_tpm2_init_pei.c'),'-o',str(ROOT/'build/test_tpm2_init_pei')],check=True)
subprocess.run([str(ROOT/'build/test_tpm2_init_pei')],check=True)
subprocess.run(['python3','-m','unittest','discover','-s','tests','-p','test_*.py','-v'],check=True,cwd=ROOT)
images={'stock':ROOT/'Official_latest_bios_update/DOS Flash/L01_0278.BIN',
        'v2':ROOT/'L01_0278_TPM2_v2_REFERENCE_ONLY.bin'}
logs={}
with tempfile.TemporaryDirectory(prefix='l01-validate-') as folder:
    rebuild=Path(folder)/'rebuild_REFERENCE_ONLY.bin'
    subprocess.run(['python3',str(ROOT/'scripts/build_candidate.py'),'--reference','--output',str(rebuild)],check=True,cwd=ROOT)
    rebuild_identical=rebuild.read_bytes()==images['v2'].read_bytes()
    if not rebuild_identical: raise RuntimeError('Rebuild differs from delivered candidate')
    for name,path in images.items():
        target=Path(folder)/(name+'.bin');shutil.copyfile(path,target)
        result=subprocess.run([str(ROOT/'UEFIExtract'),str(target),'report'],capture_output=True,text=True)
        if result.returncode: raise RuntimeError(result.stderr+result.stdout)
        logs[name]=result.stdout+result.stderr
        (OUT/(name+'.uefiextract.log')).write_text(logs[name])
        report=target.with_suffix('.bin.report.txt').read_text()
        (OUT/(name+'.uefiextract.report.txt')).write_text(report)
if logs['stock']!=logs['v2']:
    raise RuntimeError('UEFIExtract diagnostics differ from baseline; investigate before using candidate')
summary={'status':'STATIC_AND_HOST_CHECKS_ONLY','extractor_version':subprocess.check_output([str(ROOT/'UEFIExtract'),'--version'],text=True).strip(),
         'extractor_sha256':hashlib.sha256((ROOT/'UEFIExtract').read_bytes()).hexdigest(),
         'same_parser_diagnostics_as_stock':True,
         'image_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in images.items()},
         'host_checks':['32 ACPI mock scenarios under ASan/UBSan','TPM Startup/PCR-bank mock-service suite under ASan/UBSan','8 build containment/integrity cases'],
         'rebuild_byte_identical':rebuild_identical,
         'not_performed':['hardware boot','board-specific build','Windows detection/readiness','S3/resume','complete measured-boot verification','independent ACPICA AML validation']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
