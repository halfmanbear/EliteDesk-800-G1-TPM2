# HP L01 TPM 2.0 investigation and v2 discovery candidate

Updated 2026-10-20. **Static and host validation only; no board was programmed or boot-tested.**

The earlier notes are retained verbatim in [the historical v1 record](analysis/TPM2_BIOS_mod_findings_v1_historical.md). Its flashing procedure and unconditional boot/recovery claims are superseded by this document.

## Current outcome

A reproducible, constrained TPM2 discovery candidate has been built:

- `L01_0278_TPM2_v2_REFERENCE_ONLY.bin`, 16,777,216 bytes.
- SHA256: `2be72be4bf9d440f18138fe9e1e8c056aa01b09ec2de017b40b7929893c638d5`.
- Manifest: [image identity, insertions, toolchain and limitations](L01_0278_TPM2_v2_REFERENCE_ONLY.bin.json).
- **Reference-only:** based on HP's distributed image. It is not a board-preserving programmer image.
- A board-specific image still requires two matching full reads from the actual board. None were supplied during this investigation. The exact model, motherboard identity, removed-chip marking and original Linux logs also remain unavailable.

The goal of v2 is to test whether a real FIFO TPM2 can initialize through firmware, produce the donor TPM2 protocol and receive an ACPI device description. Success would not establish complete measured boot, attestation, ownership provisioning, physical presence, or sleep/resume support.

## What is observed, reported, and inferred

**Reported in the prior record:** a soldered TPM was replaced with SLB9665TT2.0; Linux detected TPM2 through `tpm_tis`; Windows did not find it. Original command output, photographs and hardware traces are not retained here. These observations have not been remeasured. They support communication with the chip at that time, rather than a claim of perfect electrical behavior.

**Observed from current files:** stock L01 02.78 and v1 identities match their documented hashes. The original stock image is `Official_latest_bios_update/DOS Flash/L01_0278.BIN`, SHA256 `c13e4495042f0bda3deadf4d110bf241cdeb6679153cde001b24e7e337b4e2c1`. V1 adds platform modules but omits the actual TPM2 cores.

**Working diagnosis:** firmware integration is incomplete for the replacement TPM. Missing signatures alone do not prove the precise firmware rejection sequence. A GUID can be assembled by instructions instead of appearing contiguously, and vendor-specific initialization PPIs differ from EDK2's. The archived donor itself demonstrates both limitations of the old search method.

## Corrections to platform claims

Details and primary-source links are in [platform_sources.md](analysis/platform_sources.md).

| Earlier claim | Investigated result |
|---|---|
| Original TPM was SLB9660; replacement is a proven pin-compatible drop-in | HP family documentation lists SLB9656 for the relevant G1 desktops. The actual removed part remains unidentified. SLB9660/9665 package compatibility does not prove compatibility with that part. |
| SP82407 converts these desktops from TPM1.2 to TPM2 | HP describes SP82407 as a security firmware update. No supporting conversion evidence was found. |
| SLB9665 can only ever run TPM2 | Infineon's family documentation discusses conversion capability; eligibility and firmware availability for this exact installed part remain unknown. No chip-firmware change was attempted. |
| Haswell has no PTT | Intel documents PTT on Haswell ULT platforms. A functioning desktop Q87/L01 PTT path remains unestablished. |
| Supermicro donor is officially compatible | Haswell/C224/AMI similarities and TPM2 code are established; exact archived board/version TPM2 certification and HP ABI compatibility are not. |
| No Boot Guard / expected boot / unconditional programmer recovery | The inspected stock FIT contains header and microcode entries, without ACM/KM/BPM entries. Board fuses and other integrity checks were not measured. No guaranteed boot or recovery follows. |
| Sure Start is the sole residual uncertainty | HP's contemporary documentation limits Sure Start to specified notebooks, rather than these G1 desktops. Module ABI, dispatch, reset and firmware integrity remain separate uncertainties. |
| All EliteDesk800G1 chassis use L01 | The supplied SP103785 model list does not include Desktop Mini. Package effective date is 2020-04-29; internal build date is a separate field. |

The old pinout also omitted pin9's backward-compatible reset allowance. No new wiring instructions are inferred from family datasheets; the actual board wiring still needs identification.

## Binary findings that changed the candidate

See [dependencies.md](analysis/dependencies.md), its linked DEPEX inventory/disassembly, and retained REA Evidence bundles `analysis/rea_*.json`.

1. **The actual core was missing.** `TrEEPei` (`20341ce2-d448-4b5e-9411-fe9826402dcf`) produces the `86f5680a...` PPI. `TrEEDxe` (`12345756-fca3-49bd-8dae-c7bae8389aff`) installs `607f766c...`, the TPM2/TrEE protocol. V1 contained neither. Its `Tpm20PlatformDxe` requires that protocol before dispatch and consumes it at entry; it is not the producer.
2. **Policy GUID equality did not imply ABI compatibility.** HP DXE policy allocates 0x30 bytes with revision1 and callback+0x28. The donor allocates 0x28 bytes with revision2 and callback+0x20. The donor core calls+0x20. PEI field mappings also differ. Copying donor Setup readers would interpret Supermicro offsets in HP variables.
3. **Core DXE needs a successful initialization HOB.** `7cea4f7e-2052-46ed-befd-e22a44dc65e7` is checked before protocol publication. Its data byte0 is readiness and byte1 chooses FIFO versus CRB. Merely inserting the cores is insufficient.
4. **Donor platform PEI is board-dependent.** It contains fixed donor FV measurement ranges. Those assumptions were not transplanted.
5. **Donor ACPI is board-dependent.** It edits AML markers such as `AMDT`, `TPMM`, `DTPT` and `FTPM` that are absent from the inspected HP leaf bodies. Its abort paths make it unsuitable unchanged.
6. **Parsing is not warning-free.** Stock already produces alignment, a file-checksum, padding and JEDEC warnings. V2 produces the same diagnostics, rather than being described as universally clean.

## V2 design

There are six distinct FFS modules, with each of the three PEI modules inserted in both PEI volumes. No existing HP module is removed or replaced.

| Module | Behavior |
|---|---|
| Source-built private policy PEI | Publishes a separate policy PPI after memory discovery. Fixed diagnostic enable gates and SHA256 selection; no HP Setup interpretation. |
| Donor TrEEPei, isolated | Original PE code except two audited policy GUID Data1 immediates. Original DEPEX plus the private policy dependency. Provides transport and core PEI services. |
| Source-built initialization PEI | Uses the donor PPI's observed five-argument Transmit ABI. Checks cold-boot mode and FIFO interface, sends Startup(CLEAR), validates response, then queries active PCR banks. Creates readiness HOB only after success or already-started response **and** active SHA256 PCR0–23. No PCR allocation or ownership/clear commands. |
| Source-built private policy DXE | Provides the donor-compatible revision2 layout under a private GUID. Callback is a diagnostic no-persistence acknowledgement; no F10 settings or production policy management. |
| Donor TrEEDxe, isolated | Original PE code except four audited policy GUID Data1 immediates. Original DEPEX plus private policy. Retains its protocol and event-log behavior, without claiming complete coverage. |
| Source-built ACPI DXE | At ReadyToBoot, rechecks protocol presence and installed ACPI tables. Adds its own minimal MSFT0101 SSDT plus historical revision3 TPM2 table, start method6/FIFO, control area0. No donor DSDT patching. |

Private policy GUIDs:

- PEI: `a4910111-b50a-401d-8b35-5124b0ba4104`.
- DXE: `a4910222-e072-40d2-a6eb-bab75bde87e7`.

The policy literals are patched only after exact PE SHA256 and expected-byte checks. DEPEX hashes are pinned. Added private-policy dependencies prevent the core drivers from dispatching before the adapters. HP's original policy and Setup code remains byte-identical.

Initialization accepts either an explicit FIFO interface ID0 or the donor-supported legacy all-ones optional ID, with valid ACCESS and nonzero/non-all-ones DID_VID presence checks. Explicit interface type15 and CRB remain unsupported by this integration. Initialization permits PI modes0–4 and6. S3/S4, manufacturing, firmware-update and recovery modes are excluded. V2 does not implement resume. An absent/unallocated SHA256 bank is a diagnostic rejection, not authorization to change PCR allocation.

ACPI defines `\_SB.ZTP2`, `_HID=MSFT0101`, `_UID=L01-DIAG-TPM2`, `_STA=0x0F`, and a polling memory resource at `0xFED40000`, length0x5000. Existing TPM2 tables or MSFT0101/ZTP2 byte signatures in installed DSDT/SSDT cause refusal, including a dormant PTT device. If TPM2 installation fails, the driver attempts to remove its SSDT. See [ACPI design and limitations](analysis/acpi_design.md).

Excluded from v2: donor policy readers, donor platform PEI/DXE, donor ACPI, `AmiTcgNvflagSample` and `TpmClearOnRollback`. Their inclusion is not required to close the demonstrated core dependencies, and would add unvalidated behavior.

## Preservation and reproducibility

[Build script](scripts/build_candidate.py), [source](src/), [input identities](inputs/manifest.json), original donor archive/image and decompressed core PE/DEPEX inputs are retained locally. The donor SHA256 is `29e07b5287eeaebdc338ed57523d649e9d4f7f79a501fa708d9f18b0f4329463`. The archive was recovered from the prior local scratchpad, not authenticated against a vendor signature.

Reference rebuild, with a fresh output path:

```sh
python3 scripts/build_candidate.py --reference \
  --output /private/tmp/L01_TPM2_rebuild_REFERENCE_ONLY.bin
```

Board-preserving build **after actual matching reads exist**, substituting their real paths:

```sh
python3 scripts/build_candidate.py \
  --base /path/to/read1.bin --second-read /path/to/read2.bin \
  --output /path/to/L01_TPM2_board_candidate.bin
```

Two different paths with identical contents are required. This verifies file equality, not that hardware was genuinely read twice. The builder rejects the vendor image as a board backup, altered FV layouts, occupied tails, collisions, bad FV checksums and existing output files. It preserves every byte outside the explicit inserted FFS spans, including any existing ME, descriptor, GbE, NVRAM, platform data and boot block. Board layout rejection is a request for further analysis; do not force the offsets.

The reference candidate changes 106,177 bytes, exclusively in newly inserted files at erased tails of DXE FV0 and PEI FV2/FV3. FIT/microcode and all pre-existing firmware files remain unchanged. Existing state is preserved relative to the supplied base; a vendor base still lacks the board's original state.

Toolchain: existing Apple clang21 Windows COFF targets and GNU mingw-w64 PE linkers. New images retain real relocation directories and no nonempty import descriptors. `UEFIExtract` present here is **NE alpha72**, not the previously named A75. Output manifests record tool versions and source hashes.

## Validation and remaining gates

Run the reproducible static/host check bundle:

```sh
python3 scripts/validate_candidate.py
```

Observed results are retained in [validation/summary.json](analysis/validation/summary.json):

- Independent UEFIExtract diagnostics match the stock baseline, including unchanged FIT/microcode output.
- Byte-identical reference rebuild.
- Eight containment/integrity tests, including preserved synthetic board-state changes and refusal of corrupt/mismatched inputs.
- PEI mock-service tests under ASan/UBSan for transport, responses, boot modes, HOB publication and SHA256 bank checks.
- Thirty-two ACPI mock scenarios under ASan/UBSan for presence gates, late table publication, duplicates, malformed tables, event failures and rollback.

**Not performed:** actual board build, hardware POST/boot, Windows discovery/readiness, firmware reset behavior, resume, complete PCR/event-log coverage, or independent ACPICA compilation of generated AML. The generator has readable ASL and an optional `--iasl` round-trip path; no iasl binary was available. Host tests do not validate firmware dispatch or hardware MMIO timing.

## Hardware acceptance sequence, still pending

1. Identify exact board/model and SPI part; retain two matching full reads plus off-board recovery copies and their hashes. Independently confirm that the existing image boots and that programmer read/verify is reliable.
2. Build against those reads; inspect the manifest and preservation check before any hardware experiment. No flashing operation is performed by these scripts.
3. After an authorized hardware test, record POST, boot path and whether the TPM2 protocol exists before OS boot. Failure here must not be attributed to ACPI alone.
4. Inspect installed DSDT/SSDT/TPM2 tables and compare device resources. A dormant installed PTT description may intentionally block this candidate's ACPI publisher.
5. In Windows, record `Get-Tpm` and `Get-CimInstance -Namespace root/cimv2/security/microsofttpm -ClassName Win32_Tpm`. Obtain `SpecVersion` and manufacturer properties from Win32_Tpm; do not assume Get-Tpm has identical fields. TPM presence is separate from readiness and provisioning.
6. Validate cold restart, firmware configuration and TPM command behavior. Treat measured boot, BitLocker/attestation and sleep/resume as separate acceptance work; v2 is not evidence for those uses.

Recovery means attempting to restore the verified board backup with the external programmer. It is a recovery method, not a guarantee against every failure. No promise of successful POST, permanent recovery, or production TPM2 support is made.
