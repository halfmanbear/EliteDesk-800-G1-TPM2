"""Offline containment, FFS-integrity and fail-closed build checks."""
import importlib.util
import json
import struct
import unittest
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('builder',ROOT/'scripts/build_candidate.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

class CandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stock=b.STOCK.read_bytes()
        cls.modules={p.stem:p.read_bytes() for p in (ROOT/'build').glob('*.ffs')}
        cls.result,cls.writes=b.apply_modules(cls.stock,cls.stock,cls.modules)

    def test_delivered_image_matches_verified_reconstruction(self):
        delivered=(ROOT/'L01_0278_TPM2_v2_REFERENCE_ONLY.bin').read_bytes()
        self.assertEqual(delivered,self.result)
        manifest=json.loads((ROOT/'L01_0278_TPM2_v2_REFERENCE_ONLY.bin.json').read_text())
        self.assertEqual(manifest['output_sha256'],b.digest(delivered))
        self.assertTrue(manifest['reference_only'])

    def test_preserves_simulated_board_data_and_existing_firmware(self):
        # Synthetic byte changes prove containment only, not actual board acceptance.
        board=bytearray(self.stock)
        for offset in [0x1000,0x200000,0x5d0000]: board[offset]^=0x31
        patched,writes=b.apply_modules(bytes(board),self.stock,self.modules)
        cursor=0
        for w in sorted(writes,key=lambda x:x['offset']):
            self.assertEqual(patched[cursor:w['offset']],board[cursor:w['offset']])
            cursor=w['offset']+w['size']
        self.assertEqual(patched[cursor:],board[cursor:])

    def test_occupied_tail_refused(self):
        modified=bytearray(self.stock);modified[0x908908]=0
        with self.assertRaises(ValueError): b.apply_modules(modified,self.stock,self.modules)

    def test_different_layout_refused(self):
        modified=bytearray(self.stock);modified[0x5e0048]^=1
        with self.assertRaises(ValueError): b.apply_modules(modified,self.stock,self.modules)

    def test_fv_header_corruption_refused(self):
        modified=bytearray(self.stock);modified[0x5e0032]^=1
        with self.assertRaises(ValueError): b.apply_modules(modified,self.stock,self.modules)

    def test_duplicate_candidate_refused(self):
        with self.assertRaises(ValueError): b.apply_modules(self.result,self.stock,self.modules)

    def test_core_identity_required(self):
        for name in ['TrEEPei','TrEEDxe']:
            original=(ROOT/'inputs/core'/f'{name}.pe32').read_bytes()
            damaged=bytearray(original);damaged[-1]^=1
            with self.assertRaises(ValueError): b.patch_core(name,damaged)

    def test_independent_ffs_and_sections_validation(self):
        for name,blob in self.modules.items():
            h=bytearray(blob[:24]);h[17]=h[23]=0
            self.assertEqual(sum(h)&255,0,name)
            self.assertEqual((sum(blob[24:])+blob[17])&255,0,name)
            self.assertEqual(blob[19]&0x40,0x40)
            self.assertEqual(int.from_bytes(blob[20:23],'little'),len(blob))
            offset=24;sections=[]
            while offset<len(blob):
                size=int.from_bytes(blob[offset:offset+3],'little')
                self.assertGreaterEqual(size,4)
                self.assertLessEqual(offset+size,len(blob))
                sections.append((blob[offset+3],blob[offset+4:offset+size]))
                offset=(offset+size+3)&~3
            self.assertEqual([k for k,_ in sections],[0x1b if name in ['TrEEPei','PolicyPei','InitPei'] else 0x13,0x10,0x15])
            dependency=sections[0][1]
            self.assertEqual(dependency[-1],8)
            if name in ['TrEEPei','TrEEDxe']:
                private=b.PEI_POLICY if name=='TrEEPei' else b.DXE_POLICY
                self.assertIn(uuid.UUID(private).bytes_le,dependency)
                original=(ROOT/'inputs/core'/f'{name}.pe32').read_bytes()
                new=sections[1][1]
                oldval,newval,sites=b.PATCHES[name]
                expected=set(j for s in sites for j in range(s,s+4))
                self.assertEqual(len(new),len(original))
                self.assertTrue(all(i in expected for i,(x,y) in enumerate(zip(original,new)) if x!=y))
                for s in sites: self.assertEqual(struct.unpack_from('<I',new,s)[0],newval)

if __name__=='__main__': unittest.main()
