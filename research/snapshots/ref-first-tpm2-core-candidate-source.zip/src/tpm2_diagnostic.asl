/* Diagnostic polling-only TPM2 exposure; no physical-presence or reset _DSM. */
DefinitionBlock ("", "SSDT", 2, "ZENDI ", "L01TPM2 ", 1)
{
    Scope (\_SB)
    {
        Device (ZTP2)
        {
            Name (_HID, "MSFT0101")
            Name (_UID, "L01-DIAG-TPM2")
            Name (_STA, 0x0F)
            Name (_CRS, ResourceTemplate ()
            {
                Memory32Fixed (ReadOnly, 0xFED40000, 0x00005000)
            })
        }
    }
}
